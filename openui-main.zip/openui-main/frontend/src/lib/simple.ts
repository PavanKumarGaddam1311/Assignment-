const simple = {
	inherit: true,
	base: 'vs-dark',
	rules: [
		{
			foreground: '#E394DC',
			token: 'string'
		}
	]
}
export default simple
